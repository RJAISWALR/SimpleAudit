# Contributing to SimpleAudit.EFCore

Thank you for your interest in contributing! 🎉

## Getting Started

1. **Fork the repository** and clone it locally
2. **Install .NET 8.0 SDK** or later
3. **Open the solution** in Visual Studio 2022, Rider, or VS Code

```bash
git clone https://github.com/yourusername/SimpleAudit.EFCore.git
cd SimpleAudit.EFCore
dotnet restore
dotnet build
```

## Running Tests

```bash
dotnet test
```

All tests must pass before submitting a PR.

## Code Guidelines

### Style
- Use **modern C# features** (records, pattern matching, init-only properties)
- Follow **Microsoft's C# naming conventions**
- Use **nullable reference types** (`#nullable enable`)
- Prefer **expression-bodied members** when appropriate
- Keep methods **small and focused**

### Performance
- Avoid reflection in hot paths (use source generators instead)
- Use `ValueTask` for potentially synchronous operations
- Avoid allocations in critical paths
- Benchmark changes that affect performance

### Testing
- Write unit tests for all new features
- Maintain >80% code coverage
- Use descriptive test names: `MethodName_WhenCondition_ExpectedResult`

## Submitting Changes

1. **Create a feature branch** from `develop`:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Write your code** following the guidelines above

3. **Write tests** for your changes

4. **Update documentation** if needed (README, XML comments)

5. **Commit with clear messages**:
   ```bash
   git commit -m "Add support for custom audit serializers"
   ```

6. **Push to your fork**:
   ```bash
   git push origin feature/your-feature-name
   ```

7. **Open a Pull Request** against the `develop` branch

## Pull Request Guidelines

### PR Description Template
```markdown
## Description
Brief description of what this PR does

## Changes
- List of changes made
- Another change

## Testing
How this was tested

## Breaking Changes
Any breaking changes (if applicable)
```

### Before Submitting
- [ ] All tests pass
- [ ] Code follows style guidelines
- [ ] XML documentation added for public APIs
- [ ] README updated (if needed)
- [ ] No merge conflicts

## Reporting Issues

When reporting bugs, please include:
- **EF Core version** and database provider
- **SimpleAudit.EFCore version**
- **Minimal reproduction** (code sample or repo)
- **Expected vs actual behavior**
- **Stack trace** (if applicable)

## Feature Requests

We love feature requests! Please:
- Check existing issues first to avoid duplicates
- Explain the **use case** and **motivation**
- Describe the **proposed API** or behavior
- Consider implementing it yourself and submitting a PR!

## Development Workflow

### Branch Strategy
- `main` - Latest stable release
- `develop` - Integration branch for next release
- `feature/*` - New features
- `bugfix/*` - Bug fixes
- `release/*` - Release preparation

### Release Process
1. Merge features into `develop`
2. Create `release/vX.Y.Z` branch
3. Bump version numbers
4. Final testing
5. Merge to `main` and tag
6. Publish to NuGet

## Code Review Process

All PRs require:
- At least one approval from a maintainer
- All CI checks passing
- No merge conflicts

We aim to review PRs within 3 business days.

## Questions?

- Open a [Discussion](https://github.com/yourusername/SimpleAudit.EFCore/discussions)
- Ask in the PR comments
- Reach out to maintainers

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for helping make SimpleAudit.EFCore better! 🚀
