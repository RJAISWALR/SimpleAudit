namespace SimpleAudit.EFCore.Entities;

/// <summary>
/// Internal audit log entity. This is stored as a shadow entity and doesn't
/// need to be included in your domain model.
/// </summary>
public sealed class AuditLog
{
    /// <summary>
    /// Unique identifier for this audit entry
    /// </summary>
    public long Id { get; init; }

    /// <summary>
    /// The name of the table that was modified
    /// </summary>
    public string TableName { get; init; } = string.Empty;

    /// <summary>
    /// The primary key value(s) of the entity that was modified
    /// </summary>
    public string EntityId { get; init; } = string.Empty;

    /// <summary>
    /// The type of change: Created, Modified, or Deleted
    /// </summary>
    public string Action { get; init; } = string.Empty;

    /// <summary>
    /// JSON snapshot of the entity before the change (null for Created)
    /// </summary>
    public string? OldValues { get; init; }

    /// <summary>
    /// JSON snapshot of the entity after the change (null for Deleted)
    /// </summary>
    public string? NewValues { get; init; }

    /// <summary>
    /// List of property names that changed (for Modified actions)
    /// </summary>
    public string? ChangedProperties { get; init; }

    /// <summary>
    /// The user who made the change (from UserProvider)
    /// </summary>
    public string? UserId { get; init; }

    /// <summary>
    /// UTC timestamp when the change occurred
    /// </summary>
    public DateTime ChangedAt { get; init; }

    /// <summary>
    /// Optional: IP address or other context info
    /// </summary>
    public string? Metadata { get; init; }
}
