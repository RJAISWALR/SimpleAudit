using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace SimpleAudit.EFCore.Serialization;

/// <summary>
/// Default serializer using System.Text.Json with [DoNotAudit] attribute support
/// </summary>
internal sealed class DefaultAuditSerializer : IAuditSerializer
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        ReferenceHandler = ReferenceHandler.IgnoreCycles
    };

    public string SerializeOriginalValues(EntityEntry entry)
    {
        var values = new Dictionary<string, object?>();

        foreach (var property in entry.Properties)
        {
            if (ShouldIncludeProperty(property.Metadata.PropertyInfo))
            {
                values[property.Metadata.Name] = property.OriginalValue;
            }
        }

        return JsonSerializer.Serialize(values, JsonOptions);
    }

    public string SerializeCurrentValues(EntityEntry entry)
    {
        var values = new Dictionary<string, object?>();

        foreach (var property in entry.Properties)
        {
            if (ShouldIncludeProperty(property.Metadata.PropertyInfo))
            {
                values[property.Metadata.Name] = property.CurrentValue;
            }
        }

        return JsonSerializer.Serialize(values, JsonOptions);
    }

    private static bool ShouldIncludeProperty(PropertyInfo? propertyInfo)
    {
        if (propertyInfo is null)
            return true;

        // Check for [DoNotAudit] attribute
        return !propertyInfo.IsDefined(typeof(DoNotAuditAttribute), inherit: true);
    }
}
