using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace SimpleAudit.EFCore.Serialization;

/// <summary>
/// Interface for serializing entity values to JSON.
/// The default implementation uses System.Text.Json with attribute-based exclusion.
/// </summary>
public interface IAuditSerializer
{
    /// <summary>
    /// Serialize the original values of an entity entry (before changes)
    /// </summary>
    string SerializeOriginalValues(EntityEntry entry);

    /// <summary>
    /// Serialize the current values of an entity entry (after changes)
    /// </summary>
    string SerializeCurrentValues(EntityEntry entry);
}
