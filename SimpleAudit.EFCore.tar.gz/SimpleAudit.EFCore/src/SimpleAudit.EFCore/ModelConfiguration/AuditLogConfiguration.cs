using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SimpleAudit.EFCore.Configuration;
using SimpleAudit.EFCore.Entities;

namespace SimpleAudit.EFCore.ModelConfiguration;

/// <summary>
/// Configures the AuditLog entity as a shadow entity in the model
/// </summary>
internal sealed class AuditLogConfiguration : IEntityTypeConfiguration<AuditLog>
{
    private readonly AuditOptions _options;

    public AuditLogConfiguration(AuditOptions options)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
    }

    public void Configure(EntityTypeBuilder<AuditLog> builder)
    {
        builder.ToTable(_options.AuditTableName, _options.AuditSchema);

        builder.HasKey(a => a.Id);

        builder.Property(a => a.Id)
            .ValueGeneratedOnAdd();

        builder.Property(a => a.TableName)
            .IsRequired()
            .HasMaxLength(255);

        builder.Property(a => a.EntityId)
            .IsRequired()
            .HasMaxLength(255);

        builder.Property(a => a.Action)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(a => a.OldValues)
            .HasColumnType("nvarchar(max)");

        builder.Property(a => a.NewValues)
            .HasColumnType("nvarchar(max)");

        builder.Property(a => a.ChangedProperties)
            .HasMaxLength(1000);

        builder.Property(a => a.UserId)
            .HasMaxLength(255);

        builder.Property(a => a.ChangedAt)
            .IsRequired();

        builder.Property(a => a.Metadata)
            .HasMaxLength(2000);

        // Indexes for common queries
        builder.HasIndex(a => a.TableName);
        builder.HasIndex(a => a.EntityId);
        builder.HasIndex(a => a.ChangedAt);
        builder.HasIndex(a => a.UserId);
        builder.HasIndex(a => new { a.TableName, a.EntityId });
    }
}
