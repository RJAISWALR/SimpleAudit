using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Diagnostics;
using SimpleAudit.EFCore.Configuration;
using SimpleAudit.EFCore.Entities;
using SimpleAudit.EFCore.Serialization;
using System.Text.Json;

namespace SimpleAudit.EFCore.Interceptors;

/// <summary>
/// High-performance EF Core interceptor that captures audit data during SaveChanges
/// </summary>
internal sealed class AuditInterceptor : SaveChangesInterceptor
{
    private readonly AuditOptions _options;
    private readonly IAuditSerializer _serializer;

    public AuditInterceptor(AuditOptions options, IAuditSerializer serializer)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _serializer = serializer ?? throw new ArgumentNullException(nameof(serializer));
    }

    public override ValueTask<InterceptionResult<int>> SavingChangesAsync(
        DbContextEventData eventData,
        InterceptionResult<int> result,
        CancellationToken cancellationToken = default)
    {
        if (eventData.Context is null)
            return base.SavingChangesAsync(eventData, result, cancellationToken);

        CaptureAuditData(eventData.Context);

        return base.SavingChangesAsync(eventData, result, cancellationToken);
    }

    public override InterceptionResult<int> SavingChanges(
        DbContextEventData eventData,
        InterceptionResult<int> result)
    {
        if (eventData.Context is not null)
            CaptureAuditData(eventData.Context);

        return base.SavingChanges(eventData, result);
    }

    private void CaptureAuditData(DbContext context)
    {
        var auditEntries = new List<AuditLog>();
        var timestamp = DateTime.UtcNow;
        var userId = _options.UserProvider?.Invoke();
        var metadata = _options.MetadataProvider?.Invoke();

        foreach (var entry in context.ChangeTracker.Entries())
        {
            // Skip if not tracked or if excluded
            if (entry.State == EntityState.Unchanged || entry.State == EntityState.Detached)
                continue;

            // Skip AuditLog itself
            if (_options.ExcludeAuditLog && entry.Entity is AuditLog)
                continue;

            var entityType = entry.Entity.GetType();
            var entityTypeName = entityType.FullName ?? entityType.Name;

            // Skip excluded types
            if (_options.ExcludedTypes.Contains(entityTypeName))
                continue;

            // Check audit flags
            if (entry.State == EntityState.Added && !_options.AuditCreated)
                continue;
            if (entry.State == EntityState.Modified && !_options.AuditModified)
                continue;
            if (entry.State == EntityState.Deleted && !_options.AuditDeleted)
                continue;

            var auditLog = CreateAuditLog(entry, timestamp, userId, metadata);
            if (auditLog is not null)
                auditEntries.Add(auditLog);
        }

        // Add audit entries to the context in the same transaction
        if (auditEntries.Any())
        {
            context.Set<AuditLog>().AddRange(auditEntries);
        }
    }

    private AuditLog? CreateAuditLog(
        EntityEntry entry,
        DateTime timestamp,
        string? userId,
        string? metadata)
    {
        try
        {
            var entityType = entry.Metadata.ClrType;
            var tableName = entry.Metadata.GetTableName() ?? entityType.Name;
            var entityId = GetEntityId(entry);

            var action = entry.State switch
            {
                EntityState.Added => "Created",
                EntityState.Modified => "Modified",
                EntityState.Deleted => "Deleted",
                _ => "Unknown"
            };

            string? oldValues = null;
            string? newValues = null;
            string? changedProperties = null;

            switch (entry.State)
            {
                case EntityState.Added:
                    newValues = _serializer.SerializeCurrentValues(entry);
                    break;

                case EntityState.Modified:
                    oldValues = _serializer.SerializeOriginalValues(entry);
                    newValues = _serializer.SerializeCurrentValues(entry);
                    changedProperties = GetChangedProperties(entry);
                    break;

                case EntityState.Deleted:
                    oldValues = _serializer.SerializeOriginalValues(entry);
                    break;
            }

            // Truncate if needed
            oldValues = TruncateIfNeeded(oldValues);
            newValues = TruncateIfNeeded(newValues);

            return new AuditLog
            {
                TableName = tableName,
                EntityId = entityId,
                Action = action,
                OldValues = oldValues,
                NewValues = newValues,
                ChangedProperties = changedProperties,
                UserId = userId,
                ChangedAt = timestamp,
                Metadata = metadata
            };
        }
        catch (Exception ex)
        {
            // Log error but don't break the save operation
            Console.Error.WriteLine($"[SimpleAudit] Error creating audit log: {ex.Message}");
            return null;
        }
    }

    private static string GetEntityId(EntityEntry entry)
    {
        var keyValues = entry.Properties
            .Where(p => p.Metadata.IsKey())
            .Select(p => p.CurrentValue?.ToString() ?? "null");

        return string.Join(",", keyValues);
    }

    private static string GetChangedProperties(EntityEntry entry)
    {
        var changedProps = entry.Properties
            .Where(p => p.IsModified && !p.Metadata.IsPrimaryKey())
            .Select(p => p.Metadata.Name);

        return JsonSerializer.Serialize(changedProps);
    }

    private string? TruncateIfNeeded(string? json)
    {
        if (json is null || json.Length <= _options.MaxJsonLength)
            return json;

        return json[.._options.MaxJsonLength] + "... [truncated]";
    }
}
