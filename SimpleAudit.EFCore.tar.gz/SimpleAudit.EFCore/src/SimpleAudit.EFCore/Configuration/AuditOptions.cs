namespace SimpleAudit.EFCore.Configuration;

/// <summary>
/// Configuration options for SimpleAudit
/// </summary>
public sealed class AuditOptions
{
    /// <summary>
    /// Function to get the current user identifier.
    /// Example: () => httpContextAccessor.HttpContext?.User?.Identity?.Name ?? "System"
    /// </summary>
    public Func<string?>? UserProvider { get; set; }

    /// <summary>
    /// Function to get additional metadata (IP address, request ID, etc.)
    /// Example: () => JsonSerializer.Serialize(new { IP = context.Connection.RemoteIpAddress })
    /// </summary>
    public Func<string?>? MetadataProvider { get; set; }

    /// <summary>
    /// Schema name for the audit log table. Default: "audit"
    /// </summary>
    public string AuditSchema { get; set; } = "audit";

    /// <summary>
    /// Table name for audit logs. Default: "AuditLogs"
    /// </summary>
    public string AuditTableName { get; set; } = "AuditLogs";

    /// <summary>
    /// Whether to audit entity creation. Default: true
    /// </summary>
    public bool AuditCreated { get; set; } = true;

    /// <summary>
    /// Whether to audit entity modifications. Default: true
    /// </summary>
    public bool AuditModified { get; set; } = true;

    /// <summary>
    /// Whether to audit entity deletions. Default: true
    /// </summary>
    public bool AuditDeleted { get; set; } = true;

    /// <summary>
    /// Entity types to exclude from auditing (by full type name)
    /// </summary>
    public HashSet<string> ExcludedTypes { get; set; } = new();

    /// <summary>
    /// Maximum length for JSON values (prevents huge audit records). Default: 10,000 chars
    /// </summary>
    public int MaxJsonLength { get; set; } = 10_000;

    /// <summary>
    /// Exclude the AuditLog entity itself from auditing. Default: true
    /// </summary>
    internal bool ExcludeAuditLog { get; set; } = true;
}
