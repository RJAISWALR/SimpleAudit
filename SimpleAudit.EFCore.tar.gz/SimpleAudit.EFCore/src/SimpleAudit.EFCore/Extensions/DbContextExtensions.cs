using Microsoft.EntityFrameworkCore;
using SimpleAudit.EFCore.Configuration;
using SimpleAudit.EFCore.Entities;
using SimpleAudit.EFCore.ModelConfiguration;

namespace SimpleAudit.EFCore.Extensions;

/// <summary>
/// Extension methods for DbContext to enable audit functionality
/// </summary>
public static class DbContextExtensions
{
    /// <summary>
    /// Configures the audit log entity in OnModelCreating.
    /// Call this in your DbContext's OnModelCreating method.
    /// </summary>
    /// <param name="modelBuilder">The model builder</param>
    /// <param name="options">Optional audit options (if not using AddSimpleAudit)</param>
    public static void ConfigureAuditLog(
        this ModelBuilder modelBuilder,
        AuditOptions? options = null)
    {
        options ??= new AuditOptions();
        
        modelBuilder.ApplyConfiguration(new AuditLogConfiguration(options));
    }

    /// <summary>
    /// Adds the AuditLog DbSet to your context.
    /// This is optional - the interceptor will work without it.
    /// Only needed if you want to query audit logs from your DbContext.
    /// </summary>
    public static DbSet<AuditLog>? GetAuditLogs(this DbContext context)
    {
        return context.Set<AuditLog>();
    }
}
