using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using SimpleAudit.EFCore.Configuration;
using SimpleAudit.EFCore.Interceptors;
using SimpleAudit.EFCore.Serialization;

namespace SimpleAudit.EFCore.Extensions;

/// <summary>
/// Extension methods for adding SimpleAudit to DbContext
/// </summary>
public static class DbContextOptionsBuilderExtensions
{
    /// <summary>
    /// Adds automatic audit logging to this DbContext.
    /// </summary>
    /// <param name="optionsBuilder">The DbContext options builder</param>
    /// <param name="configureOptions">Action to configure audit options</param>
    /// <returns>The options builder for chaining</returns>
    public static DbContextOptionsBuilder AddSimpleAudit(
        this DbContextOptionsBuilder optionsBuilder,
        Action<AuditOptions>? configureOptions = null)
    {
        var options = new AuditOptions();
        configureOptions?.Invoke(options);

        // Register the serializer (can be replaced with custom implementation)
        var serializer = new DefaultAuditSerializer();

        // Add the interceptor
        var interceptor = new AuditInterceptor(options, serializer);
        optionsBuilder.AddInterceptors(interceptor);

        // Store options in the service provider extension
        optionsBuilder.ReplaceService<IAuditOptionsProvider, AuditOptionsProvider>(
            _ => new AuditOptionsProvider(options));

        return optionsBuilder;
    }

    /// <summary>
    /// Adds automatic audit logging with a custom serializer
    /// </summary>
    public static DbContextOptionsBuilder AddSimpleAudit(
        this DbContextOptionsBuilder optionsBuilder,
        IAuditSerializer customSerializer,
        Action<AuditOptions>? configureOptions = null)
    {
        var options = new AuditOptions();
        configureOptions?.Invoke(options);

        var interceptor = new AuditInterceptor(options, customSerializer);
        optionsBuilder.AddInterceptors(interceptor);

        optionsBuilder.ReplaceService<IAuditOptionsProvider, AuditOptionsProvider>(
            _ => new AuditOptionsProvider(options));

        return optionsBuilder;
    }
}

/// <summary>
/// Internal interface for accessing audit options from ModelCustomizer
/// </summary>
internal interface IAuditOptionsProvider
{
    AuditOptions Options { get; }
}

/// <summary>
/// Internal provider for audit options
/// </summary>
internal sealed class AuditOptionsProvider : IAuditOptionsProvider
{
    public AuditOptionsProvider(AuditOptions options)
    {
        Options = options;
    }

    public AuditOptions Options { get; }
}
