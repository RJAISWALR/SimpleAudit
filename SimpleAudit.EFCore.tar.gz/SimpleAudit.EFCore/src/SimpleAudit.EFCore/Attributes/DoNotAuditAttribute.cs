namespace SimpleAudit.EFCore;

/// <summary>
/// Marks a property to be excluded from audit logging.
/// Use this on sensitive fields like passwords, SSNs, credit cards, etc.
/// </summary>
[AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
public sealed class DoNotAuditAttribute : Attribute
{
}
