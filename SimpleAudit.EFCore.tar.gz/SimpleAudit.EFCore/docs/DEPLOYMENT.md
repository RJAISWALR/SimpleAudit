# Deployment Guide

## Publishing to NuGet

### Prerequisites

1. **NuGet Account**: Create account at [nuget.org](https://www.nuget.org/)
2. **API Key**: Generate at nuget.org → Account → API Keys
3. **.NET 8 SDK**: Install from [dot.net](https://dot.net)

### Local Build and Pack

```bash
# Clean previous builds
dotnet clean

# Restore dependencies
dotnet restore

# Build in Release mode
dotnet build -c Release

# Run tests
dotnet test -c Release

# Pack the NuGet package
dotnet pack src/SimpleAudit.EFCore/SimpleAudit.EFCore.csproj -c Release -o ./artifacts
```

### Verify Package Contents

```bash
# Install nuget.exe or use dotnet tool
dotnet tool install -g nuget

# List package contents
nuget list -Source ./artifacts -Prerelease
```

Expected structure:
```
SimpleAudit.EFCore.1.0.0.nupkg
├── lib/
│   └── net8.0/
│       ├── SimpleAudit.EFCore.dll
│       └── SimpleAudit.EFCore.xml (documentation)
├── analyzers/
│   └── dotnet/cs/
│       └── SimpleAudit.EFCore.SourceGenerator.dll
├── README.md
└── LICENSE
```

### Manual Publish

```bash
# Set your API key (one time)
dotnet nuget push ./artifacts/SimpleAudit.EFCore.1.0.0.nupkg \
    --api-key YOUR_API_KEY_HERE \
    --source https://api.nuget.org/v3/index.json
```

### Automated Publishing (GitHub Actions)

Already configured in `.github/workflows/ci-cd.yml`

**Setup:**

1. Go to GitHub Repository → Settings → Secrets
2. Add secret: `NUGET_API_KEY` with your NuGet API key
3. Create a release on GitHub:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```
4. Create release in GitHub UI with tag `v1.0.0`
5. CI/CD will automatically build, test, and publish

## Versioning Strategy

We follow [Semantic Versioning](https://semver.org/):

- **Major (X.0.0)**: Breaking changes
- **Minor (0.X.0)**: New features, backward compatible
- **Patch (0.0.X)**: Bug fixes

### Examples

- `1.0.0` → `1.0.1`: Bug fix in serializer
- `1.0.0` → `1.1.0`: Added PostgreSQL support
- `1.0.0` → `2.0.0`: Changed configuration API

### Pre-release Versions

For betas and RCs:
```bash
dotnet pack -p:PackageVersion=1.1.0-beta.1
dotnet pack -p:PackageVersion=1.1.0-rc.1
```

## Release Checklist

### Before Release

- [ ] All tests pass
- [ ] Documentation updated
- [ ] CHANGELOG.md updated
- [ ] Version bumped in .csproj
- [ ] Breaking changes documented
- [ ] Migration guide updated (if breaking changes)
- [ ] Sample project works with new version

### Creating Release

```bash
# Update version in SimpleAudit.EFCore.csproj
<Version>1.1.0</Version>

# Commit version bump
git add src/SimpleAudit.EFCore/SimpleAudit.EFCore.csproj
git commit -m "Bump version to 1.1.0"

# Tag release
git tag -a v1.1.0 -m "Release v1.1.0 - Add PostgreSQL support"
git push origin main --tags
```

### After Release

- [ ] Create GitHub Release with changelog
- [ ] Verify package on NuGet.org
- [ ] Test installation: `dotnet add package SimpleAudit.EFCore`
- [ ] Announce on social media / forums
- [ ] Update documentation site

## Package Metadata Best Practices

### .csproj Configuration

```xml
<PropertyGroup>
    <!-- Identity -->
    <PackageId>SimpleAudit.EFCore</PackageId>
    <Version>1.0.0</Version>
    <Authors>Your Name, Contributors</Authors>
    
    <!-- Description -->
    <Title>SimpleAudit for Entity Framework Core</Title>
    <Description>High-performance audit logging for EF Core using modern interceptors</Description>
    <PackageTags>efcore;audit;logging;entityframework;interceptor</PackageTags>
    
    <!-- Links -->
    <PackageProjectUrl>https://github.com/yourusername/SimpleAudit.EFCore</PackageProjectUrl>
    <RepositoryUrl>https://github.com/yourusername/SimpleAudit.EFCore</RepositoryUrl>
    <RepositoryType>git</RepositoryType>
    <PackageReadmeFile>README.md</PackageReadmeFile>
    <PackageLicenseExpression>MIT</PackageLicenseExpression>
    
    <!-- Icon (optional) -->
    <PackageIcon>icon.png</PackageIcon>
    
    <!-- Release Notes -->
    <PackageReleaseNotes>See CHANGELOG.md</PackageReleaseNotes>
</PropertyGroup>
```

## Multi-Targeting (Future)

To support multiple .NET versions:

```xml
<PropertyGroup>
    <TargetFrameworks>net8.0;net9.0</TargetFrameworks>
</PropertyGroup>

<ItemGroup Condition="'$(TargetFramework)' == 'net8.0'">
    <PackageReference Include="Microsoft.EntityFrameworkCore.Relational" Version="8.0.0" />
</ItemGroup>

<ItemGroup Condition="'$(TargetFramework)' == 'net9.0'">
    <PackageReference Include="Microsoft.EntityFrameworkCore.Relational" Version="9.0.0" />
</ItemGroup>
```

## Symbol Packages

Enable debugging into your library:

```xml
<PropertyGroup>
    <!-- Generate symbols -->
    <IncludeSymbols>true</IncludeSymbols>
    <SymbolPackageFormat>snupkg</SymbolPackageFormat>
    
    <!-- Source link -->
    <PublishRepositoryUrl>true</PublishRepositoryUrl>
    <EmbedUntrackedSources>true</EmbedUntrackedSources>
</PropertyGroup>

<ItemGroup>
    <PackageReference Include="Microsoft.SourceLink.GitHub" Version="8.0.0" PrivateAssets="All"/>
</ItemGroup>
```

## Documentation Generation

### XML Documentation

Already configured in .csproj:
```xml
<PropertyGroup>
    <GenerateDocumentationFile>true</GenerateDocumentationFile>
    <NoWarn>$(NoWarn);1591</NoWarn> <!-- Suppress missing XML comment warnings -->
</PropertyGroup>
```

### DocFX (Optional)

Generate documentation website:

```bash
dotnet tool install -g docfx
docfx init -q
docfx docfx.json --serve
```

## Package Validation

Before publishing, validate:

```bash
# Install validation tool
dotnet tool install -g dotnet-validate

# Validate package
dotnet validate package ./artifacts/SimpleAudit.EFCore.1.0.0.nupkg
```

## Testing Package Locally

Before publishing to NuGet, test locally:

### Option 1: Local NuGet Feed

```bash
# Create local feed directory
mkdir ~/local-nuget

# Copy package
cp ./artifacts/*.nupkg ~/local-nuget/

# Add as source
dotnet nuget add source ~/local-nuget --name LocalFeed

# Install in test project
dotnet add package SimpleAudit.EFCore --source LocalFeed
```

### Option 2: Direct Project Reference

```xml
<ItemGroup>
    <PackageReference Include="SimpleAudit.EFCore" Version="1.0.0">
        <!-- Point directly to built DLL -->
        <HintPath>../../SimpleAudit.EFCore/src/SimpleAudit.EFCore/bin/Release/net8.0/SimpleAudit.EFCore.dll</HintPath>
    </PackageReference>
</ItemGroup>
```

## Continuous Delivery Pipeline

### Full Automated Flow

```mermaid
graph LR
    A[Commit] --> B[Build]
    B --> C[Test]
    C --> D[Pack]
    D --> E{Tag?}
    E -->|Yes| F[Publish to NuGet]
    E -->|No| G[Store Artifact]
```

### GitHub Actions Configuration

See `.github/workflows/ci-cd.yml` for complete setup.

**Key steps:**
1. Checkout code
2. Setup .NET
3. Restore dependencies
4. Build solution
5. Run tests
6. Pack NuGet package (on release)
7. Push to NuGet (on release with tag)

## Security Considerations

### Signing Packages

```xml
<PropertyGroup>
    <SignAssembly>true</SignAssembly>
    <AssemblyOriginatorKeyFile>key.snk</AssemblyOriginatorKeyFile>
</PropertyGroup>
```

Generate key:
```bash
sn -k key.snk
```

### Vulnerability Scanning

```bash
# Scan for vulnerabilities
dotnet list package --vulnerable

# Update vulnerable packages
dotnet outdated
```

## Monitoring Package Usage

### NuGet.org Stats

Monitor on nuget.org:
- Download count
- Version distribution
- Dependency tree

### GitHub Insights

Track on GitHub:
- Stars/Forks
- Issues/PRs
- Traffic analytics

## Support Channels

After release, maintain:

1. **GitHub Discussions**: Q&A and feature requests
2. **GitHub Issues**: Bug reports
3. **NuGet Q&A**: Installation help
4. **Stack Overflow**: Tag with `simpleaudit-efcore`

## Deprecation Policy

When deprecating features:

1. Mark with `[Obsolete]` attribute
2. Document in CHANGELOG
3. Provide migration guide
4. Keep for at least 2 major versions
5. Remove in next major version

Example:
```csharp
[Obsolete("Use AuditOptions.UserProvider instead. Will be removed in v3.0")]
public string CurrentUser { get; set; }
```

---

## Quick Reference

### Version 1.0.0 Release Commands

```bash
# Full release workflow
git checkout main
git pull origin main

# Update version
# Edit src/SimpleAudit.EFCore/SimpleAudit.EFCore.csproj

# Commit and tag
git add .
git commit -m "Release v1.0.0"
git tag -a v1.0.0 -m "Initial release"
git push origin main --tags

# Create GitHub Release (triggers CI/CD)
# Go to GitHub → Releases → Create new release
# - Tag: v1.0.0
# - Title: "v1.0.0 - Initial Release"
# - Description: Copy from CHANGELOG.md

# Monitor CI/CD
# Check GitHub Actions for build status
# Verify on NuGet.org after ~5 minutes
```
