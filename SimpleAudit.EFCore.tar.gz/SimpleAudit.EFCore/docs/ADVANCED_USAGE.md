# Advanced Usage Guide

## Table of Contents
- [Custom Serializers](#custom-serializers)
- [Querying Audit Logs](#querying-audit-logs)
- [Multi-Tenancy](#multi-tenancy)
- [Performance Tuning](#performance-tuning)
- [Database-Specific Features](#database-specific-features)
- [Integration Patterns](#integration-patterns)

## Custom Serializers

Implement `IAuditSerializer` for full control over JSON serialization:

```csharp
public class CompactAuditSerializer : IAuditSerializer
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = false,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public string SerializeOriginalValues(EntityEntry entry)
    {
        // Only serialize changed properties to save space
        var values = new Dictionary<string, object?>();
        
        foreach (var property in entry.Properties.Where(p => p.IsModified))
        {
            if (!HasDoNotAuditAttribute(property))
            {
                values[property.Metadata.Name] = property.OriginalValue;
            }
        }
        
        return JsonSerializer.Serialize(values, Options);
    }

    public string SerializeCurrentValues(EntityEntry entry)
    {
        var values = new Dictionary<string, object?>();
        
        foreach (var property in entry.Properties)
        {
            if (!HasDoNotAuditAttribute(property))
            {
                values[property.Metadata.Name] = property.CurrentValue;
            }
        }
        
        return JsonSerializer.Serialize(values, Options);
    }

    private static bool HasDoNotAuditAttribute(PropertyEntry property)
    {
        return property.Metadata.PropertyInfo?
            .IsDefined(typeof(DoNotAuditAttribute), true) ?? false;
    }
}

// Register it
options.AddSimpleAudit(new CompactAuditSerializer(), auditOptions => 
{
    auditOptions.UserProvider = () => currentUser;
});
```

## Querying Audit Logs

### Entity History Timeline

```csharp
public async Task<List<AuditLogDto>> GetEntityHistory(string tableName, string entityId)
{
    return await context.GetAuditLogs()!
        .Where(a => a.TableName == tableName && a.EntityId == entityId)
        .OrderByDescending(a => a.ChangedAt)
        .Select(a => new AuditLogDto
        {
            Action = a.Action,
            ChangedBy = a.UserId,
            ChangedAt = a.ChangedAt,
            Changes = a.ChangedProperties
        })
        .ToListAsync();
}
```

### Audit Report: Daily Activity

```csharp
public async Task<Dictionary<string, int>> GetDailyActivityReport(DateTime date)
{
    var startOfDay = date.Date;
    var endOfDay = startOfDay.AddDays(1);

    return await context.GetAuditLogs()!
        .Where(a => a.ChangedAt >= startOfDay && a.ChangedAt < endOfDay)
        .GroupBy(a => a.Action)
        .Select(g => new { Action = g.Key, Count = g.Count() })
        .ToDictionaryAsync(x => x.Action, x => x.Count);
}
```

### Find Who Changed a Value

```csharp
public async Task<AuditLog?> FindWhoChangedField(
    string tableName, 
    string entityId, 
    string fieldName)
{
    return await context.GetAuditLogs()!
        .Where(a => a.TableName == tableName && 
                    a.EntityId == entityId &&
                    a.ChangedProperties!.Contains(fieldName))
        .OrderByDescending(a => a.ChangedAt)
        .FirstOrDefaultAsync();
}
```

## Multi-Tenancy

### Tenant-Scoped Auditing

```csharp
public interface ITenantProvider
{
    string GetCurrentTenant();
}

// In Program.cs
builder.Services.AddScoped<ITenantProvider, TenantProvider>();

builder.Services.AddDbContext<MultiTenantDbContext>((serviceProvider, options) =>
{
    var tenantProvider = serviceProvider.GetRequiredService<ITenantProvider>();
    var httpContextAccessor = serviceProvider.GetRequiredService<IHttpContextAccessor>();
    
    options.UseSqlServer(connectionString)
           .AddSimpleAudit(auditOptions =>
           {
               auditOptions.UserProvider = () => 
                   httpContextAccessor.HttpContext?.User?.Identity?.Name;
               
               // Include tenant in metadata
               auditOptions.MetadataProvider = () => 
                   JsonSerializer.Serialize(new 
                   { 
                       TenantId = tenantProvider.GetCurrentTenant(),
                       IP = httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
                   });
           });
});
```

### Query Audit Logs by Tenant

```csharp
public async Task<List<AuditLog>> GetTenantAuditLogs(string tenantId)
{
    return await context.GetAuditLogs()!
        .Where(a => a.Metadata!.Contains($"\"TenantId\":\"{tenantId}\""))
        .OrderByDescending(a => a.ChangedAt)
        .ToListAsync();
}
```

## Performance Tuning

### Reduce Audit Log Size

```csharp
.AddSimpleAudit(options =>
{
    // Limit JSON size to 5KB
    options.MaxJsonLength = 5_000;
    
    // Only audit important operations
    options.AuditCreated = false;  // Skip inserts if not needed
    
    // Exclude large binary fields
    options.ExcludedTypes.Add("MyApp.Models.FileAttachment");
});
```

### Batch Cleanup of Old Logs

```csharp
public async Task CleanupOldAuditLogs(int daysToKeep)
{
    var cutoffDate = DateTime.UtcNow.AddDays(-daysToKeep);
    
    await context.Database.ExecuteSqlRawAsync(
        "DELETE FROM audit.AuditLogs WHERE ChangedAt < {0}", 
        cutoffDate);
}
```

### Archiving to Cold Storage

```csharp
public async Task ArchiveOldAuditLogs(int daysToKeep)
{
    var cutoffDate = DateTime.UtcNow.AddDays(-daysToKeep);
    
    // Export to archive table
    await context.Database.ExecuteSqlRawAsync(@"
        INSERT INTO audit.AuditLogsArchive 
        SELECT * FROM audit.AuditLogs 
        WHERE ChangedAt < {0}", cutoffDate);
    
    // Delete from active table
    await context.Database.ExecuteSqlRawAsync(
        "DELETE FROM audit.AuditLogs WHERE ChangedAt < {0}", 
        cutoffDate);
}
```

## Database-Specific Features

### PostgreSQL JSON Queries

```csharp
// Query JSON fields directly in PostgreSQL
var logs = await context.GetAuditLogs()!
    .Where(a => EF.Functions.JsonContains(a.NewValues, "{\"Status\":\"Active\"}"))
    .ToListAsync();
```

### SQL Server Temporal Tables

Combine with SQL Server Temporal Tables for complete history:

```csharp
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    // Configure temporal table
    modelBuilder.Entity<Product>()
        .ToTable("Products", b => b.IsTemporal());
    
    // Add audit logging
    modelBuilder.ConfigureAuditLog();
}
```

## Integration Patterns

### With MediatR

```csharp
public class AuditBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public async Task<TResponse> Handle(
        TRequest request, 
        RequestHandlerDelegate<TResponse> next, 
        CancellationToken cancellationToken)
    {
        // Audit context is automatically captured by SimpleAudit
        // Just execute the command
        return await next();
    }
}
```

### With Hangfire Background Jobs

```csharp
public class AuditCleanupJob
{
    private readonly IDbContextFactory<MyDbContext> _contextFactory;

    [AutomaticRetry(Attempts = 3)]
    public async Task CleanupOldLogs()
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        
        var cutoffDate = DateTime.UtcNow.AddMonths(-6);
        
        await context.Database.ExecuteSqlRawAsync(
            "DELETE FROM audit.AuditLogs WHERE ChangedAt < {0}", 
            cutoffDate);
    }
}

// Schedule it
RecurringJob.AddOrUpdate<AuditCleanupJob>(
    "audit-cleanup",
    job => job.CleanupOldLogs(),
    Cron.Weekly);
```

### With SignalR for Real-Time Monitoring

```csharp
public class AuditHub : Hub
{
    public async Task SubscribeToAudit(string tableName)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, $"audit:{tableName}");
    }
}

// After SaveChanges, notify subscribers
public class AuditNotificationService
{
    private readonly IHubContext<AuditHub> _hubContext;

    public async Task NotifyAuditChange(AuditLog log)
    {
        await _hubContext.Clients
            .Group($"audit:{log.TableName}")
            .SendAsync("AuditChanged", log);
    }
}
```

## Compliance Features

### GDPR: Right to be Forgotten

```csharp
public async Task EraseUserData(string userId)
{
    // Anonymize user in audit logs
    var userLogs = await context.GetAuditLogs()!
        .Where(a => a.UserId == userId)
        .ToListAsync();
    
    foreach (var log in userLogs)
    {
        log.UserId = "[REDACTED]";
        log.Metadata = null;
    }
    
    await context.SaveChangesAsync();
}
```

### Export Audit Trail

```csharp
public async Task<byte[]> ExportAuditTrailToCsv(string entityId)
{
    var logs = await context.GetAuditLogs()!
        .Where(a => a.EntityId == entityId)
        .OrderBy(a => a.ChangedAt)
        .ToListAsync();
    
    using var memoryStream = new MemoryStream();
    using var writer = new StreamWriter(memoryStream);
    using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);
    
    csv.WriteRecords(logs);
    await writer.FlushAsync();
    
    return memoryStream.ToArray();
}
```

---

For more examples, see the [samples](../samples) directory.
