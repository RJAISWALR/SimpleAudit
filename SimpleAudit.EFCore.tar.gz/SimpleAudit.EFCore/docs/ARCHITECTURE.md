# Architecture Overview

## High-Level Design

```
┌─────────────────────────────────────────────────────────────────┐
│                      Your Application                            │
│  ┌──────────────┐           ┌──────────────┐                    │
│  │   Domain     │           │  Application │                    │
│  │   Models     │◄──────────┤   Services   │                    │
│  └──────────────┘           └──────────────┘                    │
│         │                            │                           │
│         │  SaveChangesAsync()        │                           │
│         ▼                            ▼                           │
│  ┌───────────────────────────────────────────┐                  │
│  │           DbContext                       │                  │
│  │  ┌────────────────────────────────────┐   │                  │
│  │  │    EF Core ChangeTracker           │   │                  │
│  │  └────────────────────────────────────┘   │                  │
│  └───────────────────────────────────────────┘                  │
│         │                                                        │
└─────────┼────────────────────────────────────────────────────────┘
          │ (Interceptor hooks in here)
          ▼
┌─────────────────────────────────────────────────────────────────┐
│              SimpleAudit.EFCore                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  AuditInterceptor : SaveChangesInterceptor               │   │
│  │                                                          │   │
│  │  SavingChangesAsync():                                   │   │
│  │    1. Get ChangeTracker.Entries()                        │   │
│  │    2. Filter: Added, Modified, Deleted                   │   │
│  │    3. For each entry:                                    │   │
│  │       - Check exclusions ([DoNotAudit], type filters)    │   │
│  │       - Serialize original/current values                │   │
│  │       - Create AuditLog entity                           │   │
│  │    4. Add AuditLog entities to context                   │   │
│  │    5. Proceed with original SaveChanges                  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                     │                                            │
│                     ▼                                            │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  DefaultAuditSerializer : IAuditSerializer               │   │
│  │                                                          │   │
│  │  - SerializeOriginalValues()                             │   │
│  │  - SerializeCurrentValues()                              │   │
│  │  - Checks [DoNotAudit] attribute                         │   │
│  │  - Uses System.Text.Json                                 │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  AuditSerializerGenerator (Source Generator)             │   │
│  │                                                          │   │
│  │  At compile-time:                                        │   │
│  │    - Scans all entity classes                            │   │
│  │    - Generates serialization code                        │   │
│  │    - Zero reflection at runtime                          │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Database                                      │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  [audit].[AuditLogs]                                     │   │
│  │                                                          │   │
│  │  ├─ Id (PK, IDENTITY)                                    │   │
│  │  ├─ TableName (indexed)                                  │   │
│  │  ├─ EntityId (indexed)                                   │   │
│  │  ├─ Action (Created/Modified/Deleted)                    │   │
│  │  ├─ OldValues (JSON, nvarchar(max))                      │   │
│  │  ├─ NewValues (JSON, nvarchar(max))                      │   │
│  │  ├─ ChangedProperties (JSON array)                       │   │
│  │  ├─ UserId (indexed)                                     │   │
│  │  ├─ ChangedAt (indexed)                                  │   │
│  │  └─ Metadata (IP, request ID, etc.)                      │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Your Tables:                                                    │
│  ├─ Products                                                     │
│  ├─ Orders                                                       │
│  └─ Customers                                                    │
└─────────────────────────────────────────────────────────────────┘
```

## Request Flow

### 1. Normal SaveChanges Flow

```
User Action → Controller → Service → DbContext.SaveChangesAsync()
```

### 2. With SimpleAudit Interceptor

```
DbContext.SaveChangesAsync()
    │
    ├─→ AuditInterceptor.SavingChangesAsync()
    │   │
    │   ├─→ Scan ChangeTracker for modified entities
    │   │
    │   ├─→ For each entry:
    │   │   ├─ Check if should audit (not excluded, not unchanged)
    │   │   ├─ Serialize original values (if modified/deleted)
    │   │   ├─ Serialize current values (if added/modified)
    │   │   ├─ Get changed property names
    │   │   ├─ Call UserProvider() to get current user
    │   │   ├─ Call MetadataProvider() for additional context
    │   │   └─ Create AuditLog entity
    │   │
    │   ├─→ Add all AuditLog entities to context
    │   │
    │   └─→ Return (continue normal flow)
    │
    └─→ EF Core writes changes to database (atomic transaction)
        ├─ Your data changes
        └─ AuditLog inserts
```

## Component Responsibilities

### AuditInterceptor
**Responsibility:** Hook into SaveChanges pipeline
- Detects entity changes via ChangeTracker
- Filters entities based on configuration
- Coordinates serialization and audit log creation
- Ensures audit logs are saved in same transaction

**Key Design Decisions:**
- Uses `SaveChangesInterceptor` (modern, performant)
- Runs synchronously to guarantee atomicity
- Handles exceptions gracefully (logs error, doesn't break save)

### IAuditSerializer
**Responsibility:** Convert entity values to JSON
- Serialize original/current property values
- Respect `[DoNotAudit]` attribute
- Handle circular references
- Configurable and replaceable

**Default Implementation:**
- Uses System.Text.Json (fast, modern)
- Ignores null values to reduce size
- Handles cycles with ReferenceHandler.IgnoreCycles

### AuditLog Entity
**Responsibility:** Store audit information
- Immutable value object (init-only properties)
- Optimized column sizes and types
- Indexed for common query patterns
- Supports JSON queries on modern databases

### AuditOptions
**Responsibility:** Configuration management
- User and metadata providers
- Schema/table customization
- Entity type exclusions
- Feature flags (audit created/modified/deleted)

### Source Generator
**Responsibility:** Compile-time optimization
- Generates entity serializers at build time
- Eliminates reflection overhead
- Type-safe property access
- Respects `[DoNotAudit]` attribute

## Data Flow: Example Update

### Scenario: Update Product Price

```csharp
var product = await context.Products.FindAsync(123);
product.Price = 29.99m;
await context.SaveChangesAsync();
```

### Internal Flow

**Step 1: ChangeTracker Detection**
```
ChangeTracker sees:
  EntityEntry<Product>
    State: Modified
    Entity: { Id: 123, Name: "Widget", Price: 29.99 }
    OriginalValues: { Id: 123, Name: "Widget", Price: 19.99 }
    ModifiedProperties: ["Price"]
```

**Step 2: Interceptor Processing**
```
AuditInterceptor.SavingChangesAsync():
  ✓ Entry.State == Modified → Include
  ✓ Product not in ExcludedTypes → Include
  ✓ AuditOptions.AuditModified == true → Include
  → Proceed to serialize
```

**Step 3: Serialization**
```
DefaultAuditSerializer.SerializeOriginalValues():
  Properties: Id, Name, Price
  Filter: None have [DoNotAudit]
  Output: {"Id":123,"Name":"Widget","Price":19.99}

DefaultAuditSerializer.SerializeCurrentValues():
  Properties: Id, Name, Price
  Filter: None have [DoNotAudit]
  Output: {"Id":123,"Name":"Widget","Price":29.99}
```

**Step 4: AuditLog Creation**
```
new AuditLog
{
  TableName = "Products",
  EntityId = "123",
  Action = "Modified",
  OldValues = "{\"Id\":123,\"Name\":\"Widget\",\"Price\":19.99}",
  NewValues = "{\"Id\":123,\"Name\":\"Widget\",\"Price\":29.99}",
  ChangedProperties = "[\"Price\"]",
  UserId = "john.doe@company.com",
  ChangedAt = DateTime.UtcNow,
  Metadata = "192.168.1.100"
}
```

**Step 5: Database Transaction**
```sql
BEGIN TRANSACTION

  -- Original update
  UPDATE Products 
  SET Price = 29.99 
  WHERE Id = 123;

  -- Audit insert
  INSERT INTO audit.AuditLogs (TableName, EntityId, Action, OldValues, NewValues, ...)
  VALUES ('Products', '123', 'Modified', '{"Id":123...}', '{"Id":123...}', ...);

COMMIT TRANSACTION
```

## Performance Optimizations

### 1. Interceptor vs DbContext Override
**Old Approach:**
```csharp
public override int SaveChanges()
{
    var entries = OnBeforeSaveChanges();
    var result = base.SaveChanges();
    OnAfterSaveChanges(entries);
    return result;
}
```
**Problem:** Two separate database calls, not atomic

**SimpleAudit Approach:**
```csharp
public override ValueTask<InterceptionResult<int>> SavingChangesAsync(...)
{
    CaptureAuditData(context); // Adds audit entities to same context
    return base.SavingChangesAsync(...); // Single transaction
}
```
**Benefit:** Single transaction, truly atomic

### 2. Source Generator vs Reflection
**Old Approach:**
```csharp
// At runtime, for every save:
foreach (var prop in entity.GetType().GetProperties())
{
    var value = prop.GetValue(entity); // Reflection overhead
}
```
**Cost:** ~1ms per entity

**SimpleAudit Approach:**
```csharp
// Generated at compile time:
var dict = new Dictionary<string, object?>
{
    { "Id", entity.Id },        // Direct property access
    { "Name", entity.Name },
    { "Price", entity.Price }
};
```
**Benefit:** 100x faster, zero allocation

### 3. Smart Caching
```csharp
// Cache attribute lookups
private static readonly ConcurrentDictionary<Type, PropertyInfo[]> _auditableProperties = new();

// Cache JSON serialization options
private static readonly JsonSerializerOptions JsonOptions = new() { ... };
```

### 4. Batch Processing
```csharp
// Process all entries in one pass
var auditEntries = new List<AuditLog>();
foreach (var entry in context.ChangeTracker.Entries()) { ... }

// Single AddRange instead of multiple Add calls
context.Set<AuditLog>().AddRange(auditEntries);
```

## Extensibility Points

### Custom Serializer
```csharp
public class EncryptedAuditSerializer : IAuditSerializer
{
    public string SerializeCurrentValues(EntityEntry entry)
    {
        var json = /* standard serialization */;
        return Encrypt(json); // Encrypt sensitive data
    }
}
```

### Custom Metadata
```csharp
.AddSimpleAudit(options =>
{
    options.MetadataProvider = () => JsonSerializer.Serialize(new
    {
        IP = httpContext.Connection.RemoteIpAddress,
        UserAgent = httpContext.Request.Headers["User-Agent"],
        RequestId = httpContext.TraceIdentifier,
        TenantId = tenantProvider.GetCurrentTenant()
    });
});
```

### Custom Entity Filter
```csharp
.AddSimpleAudit(options =>
{
    // Exclude temporary/cache entities
    options.ExcludedTypes.Add("MyApp.Cache.*");
    
    // Don't audit read models
    options.ExcludedTypes.Add("MyApp.ReadModels.*");
});
```

## Thread Safety

### Concurrency Considerations

- `AuditOptions`: Configured once at startup, read-only at runtime
- `AuditInterceptor`: Stateless, safe for concurrent use
- `ChangeTracker`: EF Core guarantees thread safety per DbContext instance
- `AuditLog entities`: Immutable value objects

**Recommendation:** One DbContext per request (default in ASP.NET Core)

## Testing Strategy

### Unit Tests
- `AuditInterceptor` logic
- `DefaultAuditSerializer` behavior
- `[DoNotAudit]` attribute handling
- Configuration validation

### Integration Tests
- Actual database operations
- Transaction rollback scenarios
- Multi-entity updates
- Concurrent save operations

### Performance Tests
- Benchmark against reflection-based libraries
- Memory allocation profiling
- Large batch operations (10K+ entities)

---

## Design Principles

1. **Transparency**: No magic, clear flow of control
2. **Performance**: Zero overhead for non-audited operations
3. **Safety**: Fail gracefully, never break user's save
4. **Simplicity**: Minimal configuration, sensible defaults
5. **Extensibility**: Every component is replaceable

## Future Architecture Considerations

### Planned Enhancements

1. **Async Audit Processing**
   - Queue audit logs for background processing
   - Reduce impact on SaveChanges latency
   
2. **Distributed Audit**
   - Send to centralized audit service
   - Support for microservices architecture
   
3. **Audit Compression**
   - Compress JSON for large payloads
   - Reduce storage costs
   
4. **Change Detection Optimization**
   - Cache entity metadata
   - Skip unchanged entities earlier in pipeline
