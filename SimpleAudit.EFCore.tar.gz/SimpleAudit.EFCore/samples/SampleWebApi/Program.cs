using Microsoft.EntityFrameworkCore;
using SimpleAudit.EFCore;
using SimpleAudit.EFCore.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Register HttpContextAccessor for getting current user
builder.Services.AddHttpContextAccessor();

// Configure DbContext with SimpleAudit
builder.Services.AddDbContext<SampleDbContext>((serviceProvider, options) =>
{
    var httpContextAccessor = serviceProvider.GetRequiredService<IHttpContextAccessor>();
    
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
           .AddSimpleAudit(auditOptions =>
           {
               // Get current user from authentication
               auditOptions.UserProvider = () => 
                   httpContextAccessor.HttpContext?.User?.Identity?.Name ?? "Anonymous";
               
               // Add request metadata (IP address)
               auditOptions.MetadataProvider = () => 
                   httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString();
               
               // Optional: Exclude certain entity types
               auditOptions.ExcludedTypes.Add("SampleApp.Models.AuditLog");
               
               // Optional: Only audit modifications and deletions
               // auditOptions.AuditCreated = false;
           });
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Create database and seed data
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<SampleDbContext>();
    await db.Database.EnsureCreatedAsync();
    
    if (!await db.Products.AnyAsync())
    {
        db.Products.AddRange(
            new Product { Name = "Laptop", Price = 999.99m, Stock = 10 },
            new Product { Name = "Mouse", Price = 29.99m, Stock = 100 },
            new Product { Name = "Keyboard", Price = 79.99m, Stock = 50 }
        );
        await db.SaveChangesAsync();
    }
}

app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();

// Demo endpoints
app.MapGet("/api/products", async (SampleDbContext db) =>
{
    return await db.Products.ToListAsync();
});

app.MapPut("/api/products/{id}", async (int id, ProductUpdateDto dto, SampleDbContext db) =>
{
    var product = await db.Products.FindAsync(id);
    if (product is null) return Results.NotFound();
    
    product.Name = dto.Name;
    product.Price = dto.Price;
    product.Stock = dto.Stock;
    
    await db.SaveChangesAsync();
    return Results.Ok(product);
});

app.MapDelete("/api/products/{id}", async (int id, SampleDbContext db) =>
{
    var product = await db.Products.FindAsync(id);
    if (product is null) return Results.NotFound();
    
    db.Products.Remove(product);
    await db.SaveChangesAsync();
    return Results.NoContent();
});

// Audit query endpoints
app.MapGet("/api/audit", async (SampleDbContext db) =>
{
    return await db.GetAuditLogs()!
        .OrderByDescending(a => a.ChangedAt)
        .Take(100)
        .ToListAsync();
});

app.MapGet("/api/audit/product/{id}", async (int id, SampleDbContext db) =>
{
    return await db.GetAuditLogs()!
        .Where(a => a.TableName == "Products" && a.EntityId == id.ToString())
        .OrderByDescending(a => a.ChangedAt)
        .ToListAsync();
});

await app.RunAsync();

// ============ Models ============

public class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int Stock { get; set; }
}

public record ProductUpdateDto(string Name, decimal Price, int Stock);

// ============ DbContext ============

public class SampleDbContext : DbContext
{
    public SampleDbContext(DbContextOptions<SampleDbContext> options) : base(options)
    {
    }

    public DbSet<Product> Products => Set<Product>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        
        // Configure audit logging
        modelBuilder.ConfigureAuditLog();
        
        // Regular entity configuration
        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Price).HasPrecision(18, 2);
        });
    }
}
