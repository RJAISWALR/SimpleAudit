using Microsoft.EntityFrameworkCore;
using SimpleAudit.EFCore;
using SimpleAudit.EFCore.Extensions;
using Xunit;

namespace SimpleAudit.EFCore.Tests;

public class AuditInterceptorTests
{
    private TestDbContext CreateDbContext(Action<AuditOptions>? configure = null)
    {
        var options = new DbContextOptionsBuilder<TestDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .AddSimpleAudit(auditOptions =>
            {
                auditOptions.UserProvider = () => "TestUser";
                configure?.Invoke(auditOptions);
            })
            .Options;

        return new TestDbContext(options);
    }

    [Fact]
    public async Task SaveChanges_WhenEntityCreated_CreatesAuditLog()
    {
        // Arrange
        await using var context = CreateDbContext();
        var product = new TestProduct { Name = "Test", Price = 10.0m };

        // Act
        context.Products.Add(product);
        await context.SaveChangesAsync();

        // Assert
        var audit = await context.GetAuditLogs()!.FirstOrDefaultAsync();
        Assert.NotNull(audit);
        Assert.Equal("Products", audit.TableName);
        Assert.Equal("Created", audit.Action);
        Assert.NotNull(audit.NewValues);
        Assert.Null(audit.OldValues);
        Assert.Equal("TestUser", audit.UserId);
    }

    [Fact]
    public async Task SaveChanges_WhenEntityModified_CreatesAuditLogWithChanges()
    {
        // Arrange
        await using var context = CreateDbContext();
        var product = new TestProduct { Name = "Original", Price = 10.0m };
        context.Products.Add(product);
        await context.SaveChangesAsync();

        // Act
        product.Price = 20.0m;
        await context.SaveChangesAsync();

        // Assert
        var audits = await context.GetAuditLogs()!.ToListAsync();
        Assert.Equal(2, audits.Count);

        var modifiedAudit = audits.First(a => a.Action == "Modified");
        Assert.NotNull(modifiedAudit.OldValues);
        Assert.NotNull(modifiedAudit.NewValues);
        Assert.Contains("Price", modifiedAudit.ChangedProperties!);
    }

    [Fact]
    public async Task SaveChanges_WhenEntityDeleted_CreatesAuditLog()
    {
        // Arrange
        await using var context = CreateDbContext();
        var product = new TestProduct { Name = "Test", Price = 10.0m };
        context.Products.Add(product);
        await context.SaveChangesAsync();

        // Act
        context.Products.Remove(product);
        await context.SaveChangesAsync();

        // Assert
        var audits = await context.GetAuditLogs()!.ToListAsync();
        var deletedAudit = audits.First(a => a.Action == "Deleted");
        Assert.NotNull(deletedAudit.OldValues);
        Assert.Null(deletedAudit.NewValues);
    }

    [Fact]
    public async Task SaveChanges_WhenPropertyHasDoNotAudit_ExcludesFromAuditLog()
    {
        // Arrange
        await using var context = CreateDbContext();
        var user = new TestUser
        {
            Email = "test@example.com",
            PasswordHash = "secret123"
        };

        // Act
        context.Users.Add(user);
        await context.SaveChangesAsync();

        // Assert
        var audit = await context.GetAuditLogs()!.FirstOrDefaultAsync();
        Assert.NotNull(audit);
        Assert.Contains("Email", audit.NewValues!);
        Assert.DoesNotContain("PasswordHash", audit.NewValues!);
    }

    [Fact]
    public async Task SaveChanges_WhenEntityTypeExcluded_DoesNotCreateAuditLog()
    {
        // Arrange
        await using var context = CreateDbContext(options =>
        {
            options.ExcludedTypes.Add("SimpleAudit.EFCore.Tests.TestProduct");
        });
        var product = new TestProduct { Name = "Test", Price = 10.0m };

        // Act
        context.Products.Add(product);
        await context.SaveChangesAsync();

        // Assert
        var audits = await context.GetAuditLogs()!.ToListAsync();
        Assert.Empty(audits);
    }

    [Fact]
    public async Task SaveChanges_WhenAuditCreatedDisabled_DoesNotAuditCreation()
    {
        // Arrange
        await using var context = CreateDbContext(options =>
        {
            options.AuditCreated = false;
        });
        var product = new TestProduct { Name = "Test", Price = 10.0m };

        // Act
        context.Products.Add(product);
        await context.SaveChangesAsync();

        // Assert
        var audits = await context.GetAuditLogs()!.ToListAsync();
        Assert.Empty(audits);
    }

    [Fact]
    public async Task SaveChanges_MultipleChanges_CreatesMultipleAuditLogs()
    {
        // Arrange
        await using var context = CreateDbContext();
        var product1 = new TestProduct { Name = "Product1", Price = 10.0m };
        var product2 = new TestProduct { Name = "Product2", Price = 20.0m };

        // Act
        context.Products.AddRange(product1, product2);
        await context.SaveChangesAsync();

        product1.Price = 15.0m;
        context.Products.Remove(product2);
        await context.SaveChangesAsync();

        // Assert
        var audits = await context.GetAuditLogs()!
            .OrderBy(a => a.ChangedAt)
            .ToListAsync();
        
        Assert.Equal(4, audits.Count); // 2 created, 1 modified, 1 deleted
        Assert.Equal(2, audits.Count(a => a.Action == "Created"));
        Assert.Single(audits.Where(a => a.Action == "Modified"));
        Assert.Single(audits.Where(a => a.Action == "Deleted"));
    }
}

// Test entities
public class TestProduct
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
}

public class TestUser
{
    public int Id { get; set; }
    public string Email { get; set; } = string.Empty;
    
    [DoNotAudit]
    public string PasswordHash { get; set; } = string.Empty;
}

// Test DbContext
public class TestDbContext : DbContext
{
    public TestDbContext(DbContextOptions<TestDbContext> options) : base(options)
    {
    }

    public DbSet<TestProduct> Products => Set<TestProduct>();
    public DbSet<TestUser> Users => Set<TestUser>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ConfigureAuditLog();
    }
}
