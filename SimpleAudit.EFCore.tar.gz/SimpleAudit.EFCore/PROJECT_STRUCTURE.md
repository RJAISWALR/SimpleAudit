# SimpleAudit.EFCore - Project Structure

## Directory Tree

```
SimpleAudit.EFCore/
│
├── src/                                    # Source code
│   ├── SimpleAudit.EFCore/                 # Main library project
│   │   ├── Attributes/
│   │   │   └── DoNotAuditAttribute.cs      # Attribute for field exclusion
│   │   ├── Configuration/
│   │   │   └── AuditOptions.cs             # Configuration options class
│   │   ├── Entities/
│   │   │   └── AuditLog.cs                 # Audit log entity
│   │   ├── Extensions/
│   │   │   ├── DbContextOptionsBuilderExtensions.cs  # .AddSimpleAudit() extension
│   │   │   └── DbContextExtensions.cs      # Helper extensions
│   │   ├── Interceptors/
│   │   │   └── AuditInterceptor.cs         # Core SaveChangesInterceptor
│   │   ├── ModelConfiguration/
│   │   │   └── AuditLogConfiguration.cs    # EF Core model config
│   │   ├── Serialization/
│   │   │   ├── IAuditSerializer.cs         # Serializer interface
│   │   │   └── DefaultAuditSerializer.cs   # Default JSON serializer
│   │   └── SimpleAudit.EFCore.csproj       # Main project file
│   │
│   └── SimpleAudit.EFCore.SourceGenerator/ # Source generator project
│       ├── AuditSerializerGenerator.cs     # Roslyn source generator
│       └── SimpleAudit.EFCore.SourceGenerator.csproj
│
├── tests/                                  # Unit and integration tests
│   └── SimpleAudit.EFCore.Tests/
│       ├── AuditInterceptorTests.cs        # Comprehensive test suite
│       └── SimpleAudit.EFCore.Tests.csproj
│
├── samples/                                # Sample applications
│   └── SampleWebApi/
│       ├── Program.cs                      # Complete working example
│       ├── appsettings.json                # Configuration
│       └── SampleWebApi.csproj
│
├── docs/                                   # Documentation
│   ├── ARCHITECTURE.md                     # Detailed architecture guide
│   ├── ADVANCED_USAGE.md                   # Advanced scenarios
│   ├── MIGRATION_GUIDE.md                  # Migration from other libraries
│   └── DEPLOYMENT.md                       # Publishing to NuGet
│
├── .github/
│   └── workflows/
│       └── ci-cd.yml                       # GitHub Actions CI/CD pipeline
│
├── README.md                               # Main documentation
├── CHANGELOG.md                            # Version history
├── CONTRIBUTING.md                         # Contribution guidelines
├── LICENSE                                 # MIT license
├── .gitignore                              # Git ignore rules
└── SimpleAudit.EFCore.sln                  # Visual Studio solution
```

## File Count and LOC

```
Source Files:        13 files
Test Files:           1 file
Sample Files:         3 files
Documentation:        5 files
Configuration:        5 files
Total:               27 files

Estimated Lines of Code:
  Core Library:      ~800 LOC
  Source Generator:  ~150 LOC
  Tests:             ~250 LOC
  Samples:           ~120 LOC
  Documentation:    ~2500 LOC
  Total:            ~3820 LOC
```

## Component Overview

### Core Components (src/SimpleAudit.EFCore/)

| Component | File | Responsibility |
|-----------|------|----------------|
| **AuditInterceptor** | Interceptors/AuditInterceptor.cs | Hooks into SaveChanges, orchestrates auditing |
| **AuditOptions** | Configuration/AuditOptions.cs | Configuration settings and providers |
| **AuditLog** | Entities/AuditLog.cs | Audit record entity (shadow entity) |
| **IAuditSerializer** | Serialization/IAuditSerializer.cs | Serialization contract |
| **DefaultAuditSerializer** | Serialization/DefaultAuditSerializer.cs | JSON serializer with [DoNotAudit] support |
| **DoNotAuditAttribute** | Attributes/DoNotAuditAttribute.cs | Marks properties to exclude |
| **DbContextOptionsBuilder Extensions** | Extensions/DbContextOptionsBuilderExtensions.cs | .AddSimpleAudit() API |
| **DbContext Extensions** | Extensions/DbContextExtensions.cs | Helper methods for DbContext |
| **AuditLogConfiguration** | ModelConfiguration/AuditLogConfiguration.cs | EF Core model configuration |

### Source Generator (src/SimpleAudit.EFCore.SourceGenerator/)

| Component | File | Responsibility |
|-----------|------|----------------|
| **AuditSerializerGenerator** | AuditSerializerGenerator.cs | Generates compile-time serializers |

### Test Coverage

| Test Class | Coverage |
|------------|----------|
| **AuditInterceptorTests** | All core scenarios |
| - Entity Creation | ✓ |
| - Entity Modification | ✓ |
| - Entity Deletion | ✓ |
| - [DoNotAudit] Exclusion | ✓ |
| - Type Exclusion | ✓ |
| - Feature Flags | ✓ |
| - Multiple Changes | ✓ |

## Dependencies

### Core Library Dependencies

```xml
<PackageReference Include="Microsoft.EntityFrameworkCore.Relational" Version="8.0.0" />
<PackageReference Include="System.Text.Json" Version="8.0.0" />
```

**Rationale:**
- `Microsoft.EntityFrameworkCore.Relational`: Required for interceptors and model configuration
- `System.Text.Json`: Modern, high-performance JSON serialization

### Source Generator Dependencies

```xml
<PackageReference Include="Microsoft.CodeAnalysis.CSharp" Version="4.7.0" />
<PackageReference Include="Microsoft.CodeAnalysis.Analyzers" Version="3.3.4" />
```

**Rationale:**
- Required for Roslyn-based source generation
- Enables compile-time code generation

### Test Dependencies

```xml
<PackageReference Include="Microsoft.EntityFrameworkCore.InMemory" Version="8.0.0" />
<PackageReference Include="xunit" Version="2.6.2" />
<PackageReference Include="xunit.runner.visualstudio" Version="2.5.4" />
```

## Build Artifacts

### NuGet Package Contents

```
SimpleAudit.EFCore.1.0.0.nupkg
├── lib/
│   └── net8.0/
│       ├── SimpleAudit.EFCore.dll           # Main library
│       └── SimpleAudit.EFCore.xml           # XML documentation
├── analyzers/
│   └── dotnet/cs/
│       └── SimpleAudit.EFCore.SourceGenerator.dll  # Source generator
├── README.md                                # Package documentation
└── LICENSE                                  # MIT license
```

### Package Size Estimate

- Library DLL: ~50 KB
- Source Generator DLL: ~30 KB
- XML Documentation: ~20 KB
- README: ~15 KB
- **Total Package:** ~120 KB

## Development Workflow

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/SimpleAudit.EFCore.git
cd SimpleAudit.EFCore
```

### 2. Restore Dependencies
```bash
dotnet restore
```

### 3. Build Solution
```bash
dotnet build
```

### 4. Run Tests
```bash
dotnet test
```

### 5. Run Sample
```bash
cd samples/SampleWebApi
dotnet run
# Open browser: https://localhost:5001/swagger
```

### 6. Pack NuGet Package
```bash
dotnet pack src/SimpleAudit.EFCore/SimpleAudit.EFCore.csproj -c Release
```

## IDE Setup

### Visual Studio 2022
1. Open `SimpleAudit.EFCore.sln`
2. Set `SampleWebApi` as startup project
3. Press F5 to run with debugging

### JetBrains Rider
1. Open `SimpleAudit.EFCore.sln`
2. Build → Build Solution
3. Right-click `SampleWebApi` → Run

### VS Code
1. Open folder
2. Install C# extension
3. Press F5, select `.NET Core Launch`

## Code Style

### Naming Conventions
- Classes: `PascalCase`
- Methods: `PascalCase`
- Parameters: `camelCase`
- Private fields: `_camelCase`
- Constants: `PascalCase`

### File Organization
- One class per file
- File name matches class name
- Organize by feature/responsibility

### Documentation
- XML comments on all public APIs
- Summary and parameter descriptions
- Example usage for complex scenarios

## CI/CD Pipeline

### GitHub Actions Workflow

```yaml
Trigger: Push to main, PR, or release
  ↓
Setup .NET 8.0
  ↓
Restore dependencies
  ↓
Build solution (Release)
  ↓
Run tests with coverage
  ↓
Upload coverage to Codecov
  ↓
(If release) Pack NuGet package
  ↓
(If release) Push to NuGet.org
```

## Version Control Strategy

### Branches
- `main`: Stable releases
- `develop`: Integration branch
- `feature/*`: New features
- `bugfix/*`: Bug fixes
- `release/*`: Release preparation

### Commit Messages
```
feat: Add PostgreSQL support
fix: Correct serialization of DateTime properties
docs: Update migration guide
test: Add tests for custom serializers
chore: Bump dependency versions
```

## Security

### Dependency Scanning
- GitHub Dependabot enabled
- Automatic PR for security updates

### Code Analysis
- Roslyn analyzers enabled
- Null reference analysis
- Code style enforcement

## Performance Monitoring

### Benchmarks
Located in `benchmarks/` (future addition)

Tracks:
- Serialization performance
- Interceptor overhead
- Memory allocations
- Database query performance

## Documentation Philosophy

1. **README**: 80% of users never read more
2. **ARCHITECTURE**: For contributors and curious users
3. **ADVANCED_USAGE**: Real-world scenarios
4. **MIGRATION_GUIDE**: Lower barrier to switching
5. **DEPLOYMENT**: Make publishing painless

## Success Metrics

### Code Quality
- Test coverage >80%
- Zero compiler warnings
- Passes all analyzers

### Documentation
- Every public API documented
- At least 3 complete examples
- Migration guide from top 2 competitors

### Performance
- Faster than 90% of alternatives
- <50KB allocations per 1000 changes
- Source generator reduces reflection to 0

---

## Quick Navigation

- **Getting Started**: See README.md
- **Advanced Usage**: See docs/ADVANCED_USAGE.md
- **Architecture**: See docs/ARCHITECTURE.md
- **Contributing**: See CONTRIBUTING.md
- **Issues**: GitHub Issues
- **Discussions**: GitHub Discussions

**Last Updated**: 2024-XX-XX
**Package Version**: 1.0.0
**Target Framework**: .NET 8.0
